<script>
	window.location.replace('[@url]');
</script>
